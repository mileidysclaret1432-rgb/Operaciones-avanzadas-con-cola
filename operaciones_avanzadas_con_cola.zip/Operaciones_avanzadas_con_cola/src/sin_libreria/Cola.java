
package sin_libreria;


public class Cola {
    
    private Object[] elementos;
    private int frente;
    private int finalCola;
    private int tamaño;

    public Cola(int capacidad) {
        elementos = new Object[capacidad];
        frente = 0;
        finalCola = -1;
        tamaño = 0;
    }

    // Encolar (agregar al final)
    public void encolar(Object dato) {
        if (estaLlena()) {
            System.out.println(" La cola esta llena, no se puede agregar mas.");
            return;
        }
        finalCola++;
        elementos[finalCola] = dato;
        tamaño++;
    }

    // Desencolar (sacar del frente)
    public Object desencolar() {
        if (estaVacia()) {
            System.out.println("La cola esta vacia.");
            return null;
        }
        Object eliminado = elementos[frente];
        frente++;
        tamaño--;
        return eliminado;
    }

    // Ver si está vacía
    public boolean estaVacia() {
        return tamaño == 0;
    }

    // Ver si está llena
    public boolean estaLlena() {
        return tamaño == elementos.length;
    }

    // Mostrar todos los elementos
    public void mostrarCola() {
        if (estaVacia()) {
            System.out.println("[vacia]");
            return;
        }
        for (int i = frente; i <= finalCola; i++) {
            System.out.print(elementos[i] + " | ");
        }
        System.out.println();
    }
}
