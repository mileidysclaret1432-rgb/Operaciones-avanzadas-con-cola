
package sin_libreria;
import java.util.Scanner;

public class Main {
  


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Sistema_atencion sistema = new Sistema_atencion(5, 5); // capacidad de cada cola

        int opcion;

        do {
            System.out.println("=== SISTEMA DE ATENCION DE CLIENTES ===");
            System.out.println("1. Agregar cliente");
            System.out.println("2. Atender cliente");
            System.out.println("3. Mostrar colas");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer
System.out.println("");
            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del cliente: ");
                    String nombre = sc.nextLine();

                    System.out.print("Tipo de cliente (VIP/Normal): ");
                    String tipo = sc.nextLine();

                    Cliente nuevo = new Cliente(nombre, tipo);
                    sistema.agregarCliente(nuevo);
                    break;

                case 2:
                    sistema.atenderCliente();
                    break;

                case 3:
                    sistema.mostrarColas();
                    break;

                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción no valida. Intente de nuevo.");
            }

        } while (opcion != 0);

        sc.close();
    }
    
}

