
package sin_libreria;


public class Cliente {
     private String nombre;
    private String tipo; // "VIP" o "Normal"

    // Constructor
    public Cliente(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    // Representación en texto del cliente
    @Override
    public String toString() {
        return "Cliente: " + nombre + " (" + tipo + ")";
    }
    
}
