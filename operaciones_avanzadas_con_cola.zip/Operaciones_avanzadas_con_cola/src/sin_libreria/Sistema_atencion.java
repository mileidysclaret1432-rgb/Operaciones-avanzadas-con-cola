
package sin_libreria;


public class Sistema_atencion {
     private Cola colaVIP;
    private Cola colaNormal;

    public Sistema_atencion(int capacidadVIP, int capacidadNormal) {
        colaVIP = new Cola(capacidadVIP);
        colaNormal = new Cola(capacidadNormal);
    }

    // Agregar cliente a la cola correspondiente
    public void agregarCliente(Cliente cliente) {
        if (cliente.getTipo().equalsIgnoreCase("VIP")) {
            colaVIP.encolar(cliente);
        } else {
            colaNormal.encolar(cliente);
        }
    }

    // Atender (desencolar) cliente, dando prioridad a los VIP
    public void atenderCliente() {
        if (!colaVIP.estaVacia()) {
            Cliente atendido = (Cliente) colaVIP.desencolar();
            System.out.println("Atendiendo a cliente VIP: " + atendido.getNombre());
        } else if (!colaNormal.estaVacia()) {
            Cliente atendido = (Cliente) colaNormal.desencolar();
            System.out.println("Atendiendo a cliente normal: " + atendido.getNombre());
        } else {
            System.out.println(" No hay clientes en ninguna cola.");
        }
    }

    // Mostrar el estado de ambas colas
    public void mostrarColas() {
        System.out.println("Estado actual de las colas:");
        System.out.print("Cola VIP: ");
        colaVIP.mostrarCola();
        System.out.print("Cola Normal: ");
        colaNormal.mostrarCola();
    }
    
}
