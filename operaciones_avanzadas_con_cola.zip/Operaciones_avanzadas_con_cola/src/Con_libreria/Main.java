
package Con_libreria;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
     
        
        
        Scanner sc = new Scanner(System.in);
        Queue<Cliente> colaVIP = new LinkedList<>();
        Queue<Cliente> colaNormal = new LinkedList<>();

        int opcion;
        do {
            System.out.println("--- SISTEMA DE ATENCION DE CLIENTES---");
            System.out.println("1. Agregar cliente");
            System.out.println("2. Atender cliente");
            System.out.println("3. Ver siguiente cliente");
            System.out.println("4. Mostrar colas");
            System.out.println("5. Salir");
            System.out.println("");
            System.out.print("Elige una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer
System.out.println("");
            switch (opcion) {
                case 1:
                    System.out.print("Nombre del cliente: ");
                    String nombre = sc.nextLine();
                    System.out.print("¿Es VIP? (s/n): ");
                    char tipo = sc.next().toLowerCase().charAt(0);
                    boolean esVIP = (tipo == 's');
System.out.println("");
                    Cliente cliente = new Cliente(nombre, esVIP);
                    if (esVIP) {
                        colaVIP.add(cliente);
                        System.out.println("Cliente agregado a la cola VIP.");
                    } else {
                        colaNormal.add(cliente);
                        System.out.println("Cliente agregado a la cola Normal.");
                    }
                    System.out.println("");
                    break;

                case 2:
                    if (!colaVIP.isEmpty()) {
                        Cliente atendido = colaVIP.poll();
                        System.out.println("Atendiendo cliente VIP: " + atendido.getNombre());
                    } else if (!colaNormal.isEmpty()) {
                        Cliente atendido = colaNormal.poll();
                        System.out.println("Atendiendo cliente Normal: " + atendido.getNombre());
                    } else {
                        System.out.println("No hay clientes en las colas.");
                    }
                    System.out.println("");
                    break;

                case 3:
                    if (!colaVIP.isEmpty()) {
                        System.out.println("Siguiente cliente (VIP): " + colaVIP.peek());
                    } else if (!colaNormal.isEmpty()) {
                        System.out.println("Siguiente cliente (Normal): " + colaNormal.peek());
                    } else {
                        System.out.println("No hay clientes esperando.");
                    }
                    System.out.println("");
                    break;

                case 4:
                    System.out.println("--- COLA VIP ---");
                    if (colaVIP.isEmpty()) {
                        System.out.println("Vacia");
                    } else {
                        for (Cliente c : colaVIP) {
                            System.out.println(c);
                        }
                    }

                    System.out.println("--- COLA NORMAL ---");
                    if (colaNormal.isEmpty()) {
                        System.out.println("Vacia");
                    } else {
                        for (Cliente c : colaNormal) {
                            System.out.println(c);
                        }
                    }
                    System.out.println("");
                    break;

                case 5:
                    System.out.println("Saliendo del sistema...");
                    System.out.println("");
                    break;

                default:
                    System.out.println("Opción invalida. Intenta nuevamente.");
            }

        } while (opcion != 5);

        sc.close();
    
    }
    }
    



        
