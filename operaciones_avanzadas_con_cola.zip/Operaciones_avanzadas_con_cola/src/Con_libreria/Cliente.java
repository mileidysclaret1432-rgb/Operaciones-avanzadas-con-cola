
package Con_libreria;

public class Cliente {
    
    private String nombre;
    private boolean esVIP;

    public Cliente(String nombre, boolean esVIP) {
        this.nombre = nombre;
        this.esVIP = esVIP;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean esVIP() {
        return esVIP;
    }

    @Override
    public String toString() {
        return nombre + (esVIP ? " (VIP)" : " (Normal)");
    }
}
